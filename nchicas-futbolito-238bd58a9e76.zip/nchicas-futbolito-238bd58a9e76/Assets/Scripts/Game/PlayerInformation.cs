﻿using UnityEngine;
using System.Collections;

public class PlayerInformation {

	public string fbId;
	public string name;
	public string flagImageName;
	public FieldTeam.Formation formation {get;set;}
	public string teamName {get;set;}

}
