﻿using UnityEngine;
using System.Collections;

public class TestWindow : MonoBehaviour {

	// Use this for initialization
	void Start () {
		TeamSelectionWindow.Show();
	}
}
